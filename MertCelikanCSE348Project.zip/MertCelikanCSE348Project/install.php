<?php

$servername = "localhost";
$username = "root";
$password = "mysql";
$dbname = "mert_celikan";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

/*------------ DISTRICTs TABLE START ------------*/
$sql1 = "CREATE TABLE DISTRICTs
(
    district_id INT(6) NOT NULL AUTO_INCREMENT,
    district_name VARCHAR(30) NOT NULL,
    PRIMARY KEY (district_id)
)";
/*------------ DISTRICTs TABLE END ------------*/

/*------------ CITY TABLE START ------------*/
$sql2 = "CREATE TABLE CITYs
      (
          city_id INT(6) NOT NULL AUTO_INCREMENT,
          city_name VARCHAR(30) NOT NULL,
          district_id INT(6) NOT NULL,
          PRIMARY KEY(city_id),
          FOREIGN KEY (district_id) references DISTRICTs(district_id)
      )";
/*------------ CITY TABLE END ------------*/

/*------------ HOTELS TABLE START ------------*/
$sql3 = "CREATE TABLE HOTELs
(
    hotel_id INT(10) NOT NULL AUTO_INCREMENT,
    hotel_name VARCHAR(30) NOT NULL,
    PRIMARY KEY (hotel_id)
)";
/*------------ HOTELS TABLE END ------------*/

/*------------ ROOM TYPES TABLE START ------------*/
$sql8 = "CREATE TABLE ROOMTYPEs
(
    room_type_id INT(10) NOT NULL AUTO_INCREMENT,
    typeName VARCHAR(30) NOT NULL,
    price VARCHAR(30) NOT NULL,
    PRIMARY KEY (room_type_id)
)";
/*------------ ROOM TYPES TABLE END ------------*/

/*------------ ROOMS TABLE START ------------*/
$sql7 = "CREATE TABLE ROOMs
(
    room_id INT(10) NOT NULL AUTO_INCREMENT,
    hotel_id INT(10) NOT NULL,
    room_type_id INT(10) NOT NULL,
    PRIMARY KEY (room_id),
    FOREIGN KEY (hotel_id) references HOTELs(hotel_id),
    FOREIGN KEY (room_type_id) references ROOMTYPEs(room_type_id)
)";
/*------------ ROOMS TABLE END ------------*/

/*------------ CLIENT TABLE START ------------*/
$sql4 = "CREATE TABLE CLIENT
 (
     client_id INT(6) NOT NULL AUTO_INCREMENT,
     client_name VARCHAR(30) NOT NULL,
     client_surname VARCHAR(30) NOT NULL,
     PRIMARY KEY (client_id)
 )";
/*------------ CLIENT TABLE END ------------*/

/*------------ FACILITIES TABLE START ------------*/
$sql5 = "CREATE TABLE FACILITIES
(
    facilities_id INT(10) NOT NULL AUTO_INCREMENT,
    facilitie_name VARCHAR(30) NOT NULL,
    PRIMARY KEY (facilities_id)
)";
/*------------ FACILITIES TABLE END ------------*/

/*------------ TRAVEL AGENTS TABLE START ------------*/
$sql6 = "CREATE TABLE TRAVELAGENTs
(
    travelagent_id INT(10) NOT NULL AUTO_INCREMENT,
    travelagent_name VARCHAR(30) NOT NULL,
    PRIMARY KEY (travelagent_id)
)";
/*------------ TRAVEL AGENTS TABLE END ------------*/

/*------------ BOOKING TABLE START ------------*/
$sql9 = "CREATE TABLE BOOKING
      (
          booking_id INT(10) NOT NULL AUTO_INCREMENT,
          client_id INT(10) NOT NULL,
          hotel_id INT(10) NOT NULL,
          room_id INT(10) NOT NULL,
          travelagent_id INT(10) NOT NULL,
          startDate DATE,
          endDate DATE,
          PRIMARY KEY (booking_id),
          FOREIGN KEY(client_id) references CLIENT(client_id),
        	FOREIGN KEY(hotel_id) references HOTELs(hotel_id),
        	FOREIGN KEY(room_id) references ROOMs(room_id),
          FOREIGN KEY(travelagent_id) references TRAVELAGENTs(travelagent_id)
      )";
/*------------ BOOKING TABLE END ------------*/

/*------------ FACELITIES TO HOTEL TABLE START ------------*/
$sql10 = "CREATE TABLE facelitiesToHotel
(
  hotel_id INT(10) NOT NULL,
  facilities_id INT(10) NOT NULL,
  CONSTRAINT hotel_face_pk PRIMARY KEY (hotel_id, facilities_id),
  CONSTRAINT FK_hotel 
      FOREIGN KEY (hotel_id) REFERENCES HOTELs (hotel_id),
  CONSTRAINT FK_facilities 
      FOREIGN KEY (facilities_id) REFERENCES FACILITIES (facilities_id)
)";
/*------------ FACELITIES TO HOTEL TABLE END ------------*/

/*------------ CITYS TO HOTEL TABLE START ------------*/
$sql11 = "CREATE TABLE citysToHotel
(
  hotel_id INT(10) NOT NULL,
  city_id INT(10) NOT NULL,
  CONSTRAINT hotel_city_pk PRIMARY KEY (hotel_id, city_id),
  CONSTRAINT hotel_FK 
      FOREIGN KEY (hotel_id) REFERENCES HOTELs (hotel_id),
  CONSTRAINT citys_FK 
      FOREIGN KEY (city_id) REFERENCES CITYs (city_id)
)";
/*------------ CITYS TO HOTEL TABLE END ------------*/

/*------------ CREATING TABLES ------------*/
if ($conn->query($sql1) === true) {
    echo "Table DISTRICTs created successfully.<br>";
} else {
    echo "<br>Error creating table: " . $conn->error;
}

if ($conn->query($sql2) === true) {
    echo "Table City created successfully.<br>";
} else {
    echo "<br>Error creating table: " . $conn->error;
}

if ($conn->query($sql3) === true) {
    echo "Table Hotel created successfully.<br>";
} else {
    echo "<br>Error creating table: " . $conn->error;
}

if ($conn->query($sql8) === true) {
    echo "Table ROOMTYPEs created successfully.<br>";
} else {
    echo "<br>Error creating table: " . $conn->error;
}

if ($conn->query($sql7) === true) {
    echo "Table ROOMs created successfully.<br>";
} else {
    echo "<br>Error creating table: " . $conn->error;
}

if ($conn->query($sql4) === true) {
    echo "Table Client created successfully.<br>";
} else {
    echo "<br>Error creating table: " . $conn->error;
}

if ($conn->query($sql5) === true) {
    echo "Table Facilities created successfully.<br>";
} else {
    echo "<br>Error creating table: " . $conn->error;
}

if ($conn->query($sql6) === true) {
    echo "Table TRAVELAGENTs created successfully.<br>";
} else {
    echo "<br>Error creating table: " . $conn->error;
}

if ($conn->query($sql9) === true) {
    echo "Table BOOKING created successfully.<br>";
} else {
    echo "<br>Error creating table: " . $conn->error;
}

if ($conn->query($sql10) === true) {
    echo "Table facelitiesToHotel created successfully.<br>";
} else {
    echo "<br>Error creating table: " . $conn->error;
}

if ($conn->query($sql11) === true) {
    echo "Table citysToHotel created successfully.<br>";
} else {
    echo "<br>Error creating table: " . $conn->error;
}
/*------------ CREATING TABLES END ------------*/

/*------------ DISTRICT UPLOAD CSV START  ------------*/
$filename = "csvs/district.csv";

if (!file_exists($filename) || !is_readable($filename)) {
    return false;
}

if (($handle = fopen($filename, "r")) !== false) {
    $row = fgetcsv($handle);
    while (($row = fgetcsv($handle, 1000, ",")) !== false) {
        $sql_query = "INSERT INTO DISTRICTs(district_name) VALUES('$row[1]')";
        mysqli_query($conn, $sql_query);
    }

    echo 'Filled "DISTRICT" table.<br>';
}
fclose($handle);
$handle = null;
/*------------ DISTRICT UPLOAD CSV END  ------------*/

/*------------ CITYS UPLOAD CSV START  ------------*/
$filename = "csvs/city.csv";

if (!file_exists($filename) || !is_readable($filename)) {
    return false;
}

if (($handle = fopen($filename, "r")) !== false) {
    $row = fgetcsv($handle);
    while (($row = fgetcsv($handle, 1000, ",")) !== false) {
        $sql_query = "INSERT INTO CITYs(city_name,district_id) VALUES('$row[1]','$row[2]')";
        mysqli_query($conn, $sql_query);
    }

    echo 'Filled "CITYs" table.<br>';
}
fclose($handle);
$handle = null;

/*------------ CITYS UPLOAD CSV END  ------------*/

/*------------ ROOM TYPES UPLOAD CSV START  ------------*/
$filename = "csvs/roomtypes.csv";

if (!file_exists($filename) || !is_readable($filename)) {
    return false;
}

if (($handle = fopen($filename, "r")) !== false) {
    $row = fgetcsv($handle);
    while (($row = fgetcsv($handle, 1000, ",")) !== false) {
        $sql_query = "INSERT INTO ROOMTYPEs(typeName,price) VALUES('$row[1]','$row[2]')";
        mysqli_query($conn, $sql_query);
    }

    echo 'Filled "Roomtypes" table.<br>';
}
fclose($handle);
$handle = null;

/*------------ ROOM TYPES UPLOAD CSV END  ------------*/

/*------------ HOTELS UPLOAD CSV START  ------------*/
$filename = "csvs/hotels.csv";

if (!file_exists($filename) || !is_readable($filename)) {
    return false;
}

if (($handle = fopen($filename, "r")) !== false) {
    $row = fgetcsv($handle);
    while (($row = fgetcsv($handle, 1000, ",")) !== false) {
        $sql_query = "INSERT INTO HOTELs(hotel_name) VALUES('$row[1]')";
        mysqli_query($conn, $sql_query);
    }

    echo 'Filled "hotels" table.<br>';
}
fclose($handle);
$handle = null;
/*------------ HOTELS UPLOAD CSV END  ------------*/

/*------------ FACILITIES UPLOAD CSV START  ------------*/
$filename = "csvs/facilities.csv";

if (!file_exists($filename) || !is_readable($filename)) {
    return false;
}

if (($handle = fopen($filename, "r")) !== false) {
    $row = fgetcsv($handle);
    while (($row = fgetcsv($handle, 1000, ",")) !== false) {
        $sql_query = "INSERT INTO FACILITIES(facilitie_name) VALUES('$row[1]')";
        mysqli_query($conn, $sql_query);
    }

    echo 'Filled "facilities" table.<br>';
}
fclose($handle);
$handle = null;
/*------------ FACILITIES UPLOAD CSV END  ------------*/

/*------------ TRAVEL AGENCIES UPLOAD CSV START  ------------*/

$filename = "csvs/travelagencies.csv";

if (!file_exists($filename) || !is_readable($filename)) {
    return false;
}

if (($handle = fopen($filename, "r")) !== false) {
    $row = fgetcsv($handle);
    while (($row = fgetcsv($handle, 1000, ",")) !== false) {
        $sql_query = "INSERT INTO TRAVELAGENTs(travelagent_name) VALUES('$row[1]')";
        mysqli_query($conn, $sql_query);
    }

    echo 'Filled "TRAVELAGENTs" table.<br>';
}
fclose($handle);
$handle = null;

/*------------ TRAVEL AGENTS UPLOAD CSV END  ------------*/

/// ADD FACILITIES TO HOTELS /// You should have 5 different facilities in total and every hotel should have at least 2 facilities.
for ($x = 1; $x <= 10; $x++) {
    $myrand = rand(1, 5);
    $sql_query = "INSERT INTO facelitiesToHotel(hotel_id,facilities_id) VALUES('$x','$myrand')";
    mysqli_query($conn, $sql_query);

    $myrand = rand(1, 5);
    $sql_query = "INSERT INTO facelitiesToHotel(hotel_id,facilities_id) VALUES('$x','$myrand')";
    mysqli_query($conn, $sql_query);
}

/// ADD CITYS TO HOTELS /// Every city should have 5 different randomly chosen hotels.

for ($x = 1; $x <= 81; $x++) {
    $myrand = rand(1, 10);
    $sql_query = "INSERT INTO citysToHotel(hotel_id,city_id) VALUES('$myrand','$x')";
    mysqli_query($conn, $sql_query);

    $myrand2 = rand(1, 10);
    $sql_query = "INSERT INTO citysToHotel(hotel_id,city_id) VALUES('$myrand2','$x')";
    mysqli_query($conn, $sql_query);

    $myrand3 = rand(1, 10);
    $sql_query = "INSERT INTO citysToHotel(hotel_id,city_id) VALUES('$myrand3','$x')";
    mysqli_query($conn, $sql_query);

    $myrand4 = rand(1, 10);
    $sql_query = "INSERT INTO citysToHotel(hotel_id,city_id) VALUES('$myrand4','$x')";
    mysqli_query($conn, $sql_query);

    $myrand5 = rand(1, 10);
    $sql_query = "INSERT INTO citysToHotel(hotel_id,city_id) VALUES('$myrand5','$x')";
    mysqli_query($conn, $sql_query);

    $myrand6 = rand(1, 10);
    $sql_query = "INSERT INTO citysToHotel(hotel_id,city_id) VALUES('$myrand6','$x')";
    mysqli_query($conn, $sql_query);
}

// ADD ROOM to HOTELS  // Do not forget to include the associated ROOM id. Every hotel should have exactly 30 rooms.

for ($x = 1; $x <= 10; $x++) {
    for ($j = 1; $j <= 30; $j++) {
        $myrand = rand(1, 5);
        $sql_query = "INSERT INTO ROOMs(hotel_id,room_type_id) VALUES('$x','$myrand')";
        mysqli_query($conn, $sql_query);
    }
}

// 500 random Turkish Names and 500 random Turkish Surnames are to be held in a csv file and their combinations of 1620 full names should be inserted into the CLIENT table.

$nameArr = [""];
$surNameArr = [];

$filename = "csvs/name.csv";

if (!file_exists($filename) || !is_readable($filename)) {
    return false;
}
if (($handle = fopen($filename, "r")) !== false) {
    $row = fgetcsv($handle);
    while (($row = fgetcsv($handle, 1000, ",")) !== false) {
        array_push($nameArr, $row[0]);
    }
}
fclose($handle);
$handle = null;

$filename = "csvs/surname.csv";
if (!file_exists($filename) || !is_readable($filename)) {
    return false;
}
if (($handle = fopen($filename, "r")) !== false) {
    $row = fgetcsv($handle);
    while (($row = fgetcsv($handle, 1000, ",")) !== false) {
        array_push($surNameArr, $row[0]);
    }
}
fclose($handle);
$handle = null;

for ($x = 0; $x <= 1619; $x++) {
    $myrand = rand(1, 500);
    $myrand2 = rand(1, 500);

    $sql_query = "INSERT INTO CLIENT(client_name,client_surname) VALUES('$nameArr[$myrand]','$surNameArr[$myrand2]')";
    mysqli_query($conn, $sql_query);
}

//Finally for every client, you should have at most 5 booking information with install action.

for ($x = 1; $x <= 20; $x++) {
    $myrand2 = rand(1, 10); //otelid
    $myrand4 = rand(1, 10); //travel agent id

    $myRoomId = rand($myrand2 * 30 - 30, $myrand2 * 30);

    $randomDay = rand(1, 30); //day
    $randomMonth = rand(1, 12); //month

    $randomDay2 = rand(1, 30); //day
    $randomMonth2 = rand(1, 12); //month

    $sql_query = "INSERT INTO BOOKING(client_id,hotel_id,room_id,travelagent_id,startDate,endDate) VALUES('$x','$myrand2','$myRoomId','$myrand4','2020-$randomMonth-$randomDay','2021-$randomMonth2-$randomDay2')";
    mysqli_query($conn, $sql_query);
}

$conn->close();

?>

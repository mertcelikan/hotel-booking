<?php


$servername = "localhost";
$username = "root";
$password = "mysql";
$dbname = "mert_celikan";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
} 



$agentid = $_POST['agentid'];

$sql = "SELECT room_id FROM BOOKING";
$result = mysqli_query($conn,$sql) or die("Error");

$sql2 = "SELECT COUNT(BOOKING.room_id), ROOMs.room_type_id FROM ROOMs INNER JOIN BOOKING ON ROOMs.room_id = BOOKING.room_id GROUP BY ROOMs.room_type_id;";
$result2 = mysqli_query($conn,$sql2) or die("Error");

$sql3 = "SELECT BOOKING.travelagent_id, SUM(ROOMTYPEs.price) FROM ROOMs INNER JOIN BOOKING ON ROOMs.room_id = BOOKING.travelagent_id INNER JOIN ROOMTYPEs ON ROOMs.room_type_id = ROOMTYPEs.room_type_id GROUP BY BOOKING.travelagent_id;";
$result3 = mysqli_query($conn,$sql3) or die("Error");



$myRooms=array();

if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_array($result)) {
        array_push($myRooms,$row["room_id"]);
    }	
    
} 

if(array_key_exists('roomType', $_POST)) {

    if (mysqli_num_rows($result2) > 0) {
        echo "<table border='1'>";
        echo "<tr><td>room_id</td><td>room_type_id</td></tr>";
        while($row = mysqli_fetch_array($result2)) {
            
            echo "<tr>";
            echo "<td>" . $row["COUNT(BOOKING.room_id)"] . "</td><td>" . $row["room_type_id"]. "</td>";
            echo "</tr>";
        }	
        echo "</table>";
    } 
    
}

if(array_key_exists('agency', $_POST)) {

    if (mysqli_num_rows($result3) > 0) {
        echo "<table border='1'>";
        echo "<tr><td>travelagent_id</td><td>SUM(ROOMTYPEs.price)</td></tr>";
        while($row = mysqli_fetch_array($result3)) {
            
            echo "<tr>";
            echo "<td>" . $row["travelagent_id"] . "</td><td>" . $row["SUM(ROOMTYPEs.price)"]. "</td>";
            echo "</tr>";
        }	
        echo "</table>";
    }

}

$sql4 = "SELECT ROOMTYPEs.price,TRAVELAGENTs.travelagent_name,HOTELs.hotel_name,CLIENT.client_name, CLIENT.client_surname, BOOKING.startDate, BOOKING.endDate FROM BOOKING 
INNER JOIN CLIENT ON CLIENT.client_id = BOOKING.client_id 
INNER JOIN HOTELs ON HOTELs.hotel_id = BOOKING.hotel_id
INNER JOIN TRAVELAGENTs ON TRAVELAGENTs.travelagent_id = BOOKING.travelagent_id
INNER JOIN ROOMs ON ROOMs.room_id = BOOKING.room_id
INNER JOIN ROOMTYPEs ON ROOMTYPEs.room_type_id = ROOMs.room_type_id WHERE BOOKING.travelagent_id = '$agentid';
";
$result4 = mysqli_query($conn,$sql4) or die("Error");
if(array_key_exists('agencybtn', $_POST)) {


    if (mysqli_num_rows($result4) > 0) {
        echo "<table border='1'>";
        echo "<tr><td>price</td><td>travelagent_name</td><td>hotel_name</td><td>client_name</td><td>client_surname</td><td>startDate</td><td>endDate</td></tr>";
        while($row = mysqli_fetch_array($result4)) {
            
            echo "<tr>";
            echo "<td>" . $row["price"] . "</td><td>" . $row["travelagent_name"]. "</td> <td>" . $row["hotel_name"]. "</td> <td>" . $row["client_name"]. "</td> <td>" . $row["client_surname"]. "</td> <td>" . $row["startDate"]. "</td> <td>" . $row["endDate"]. "</td>" ;
            echo "</tr>";
        }	
        echo "</table>";
    } 
    
}






mysqli_close($conn);
?>
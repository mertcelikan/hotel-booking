<?php

$servername = "localhost";
$username = "root";
$password = "mysql";
$dbname = "mert_celikan";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$cityid = $_POST['cityid'];
//$cityid = $_POST["cityid"];
$startDate = $_POST["startDate"];
$endDate = $_POST["endDate"];

$sql = "SELECT hotel_id, city_id FROM citysToHotel WHERE (city_id = '$cityid')";
($result = mysqli_query($conn, $sql)) or die("Error");

$myHotels = [];

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
        array_push($myHotels, $row["hotel_id"]);
    }
}

$hotelArr = array_map("intval", explode(",", $myHotels));
$hotelArr = implode("','", $hotelArr);

$ids = join("','", $myHotels);

$sql2 = "SELECT client_id,room_id,hotel_id,startDate, endDate FROM BOOKING WHERE hotel_id IN ('$ids') AND (startDate > $startDate) AND (endDate > $endDate)";
($result2 = mysqli_query($conn, $sql2)) or die("Error");

if (mysqli_num_rows($result2) > 0) {
    // output data of each row
    echo "<table border='1'>";
    echo "<tr><td>client_id</td><td>hotel_id</td><td>room_id</td></tr>";
    while ($row = mysqli_fetch_array($result2)) {
        echo "<tr>";
        echo "<td>" .
            $row["client_id"] .
            "</td><td>" .
            $row["hotel_id"] .
            "</td><td>" .
            $row["room_id"] .
            "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

mysqli_close($conn);
?>
